EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'treasurepuzzlehunt@gmail.com'
EMAIL_HOST_PASSWORD = 'Ru@8290213720'
EMAIL_PORT = 587